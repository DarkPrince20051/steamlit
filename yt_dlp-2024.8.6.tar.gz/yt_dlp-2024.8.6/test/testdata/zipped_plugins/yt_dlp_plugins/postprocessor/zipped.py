from yt_dlp.postprocessor.common import PostProcessor


class ZippedPluginPP(PostProcessor):
    pass
