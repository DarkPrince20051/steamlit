from yt_dlp.extractor.common import InfoExtractor


class IgnoreNotInAllPluginIE(InfoExtractor):
    pass


class InAllPluginIE(InfoExtractor):
    pass


__all__ = ['InAllPluginIE']
